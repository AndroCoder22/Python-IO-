import json
import math
import time

import pygame as pg

import control
import gui
from client import Client
from settings import *
from snake import Snake
from skins import skin_view, skins
from localization import en_strings, ru_strings

def smooth_increase(value, value2, addition, fractions):
		if round(value2, fractions) > round(value, fractions):
			value += addition
		if round(value2, fractions) < round(value, fractions):
			value -= addition
		return value

with open('colors.json', 'r') as file:
    colors = json.load(file)

default_config = {'control': 'mouse',
                  'lang': 'english',
                  'skin_id': 0}
try:
    with open('config.json', 'r') as file:
        data = json.load(file)

except:
    with open('config.json', 'w') as file:
        json.dump(default_config, file)
    
    with open('config.json', 'r') as file:
        data = json.load(file)
if data['lang'] == 'english':
    lang = en_strings.str
else:
    lang = ru_strings.str
skin_id = data['skin_id']

pg.init()
sc =  pg.display.set_mode((WIDTH, HEIGHT), pg.FULLSCREEN|pg.SCALED )
clock = pg.time.Clock()
game_font = pg.font.SysFont('robo', control.dp(20))

screen = 1 #1 - menu, 2 - setings, 3 - game 

# Menu widgets
start_button = gui.Button(sc, [-780, -200], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['start_game'], 80, [colors['Button']['text_color'], colors['Button']['text_color_focused']]))
settings_button = gui.Button(sc, [-780, 0], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['settings'], 80, [colors['Button']['text_color'], colors['Button']['text_color_focused']]))
python_io_label = gui.Label(sc, [-750, -400], "Python IO", colors['Python_IO']['color'], 100, 'B52_Regular.ttf')
message_label = gui.Label(sc, [-320, 200], "", colors['Label']['text_color'], 35)
fps_label = gui.Label(sc, [480, 370], "", colors['Label']['text_color'], 30)
developer_label = gui.Label(sc, [-800, 380], lang['developer'], colors['Label_2']['text_color'], 30)
exit_button = gui.Button(sc, [-780, 200], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['exit'], 50, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), (255,255,0))

# Settings  widgets
back_button = gui.Button(sc, [-800, -450], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['back'], 40, [colors['Button']['text_color'], colors['Button']['text_color_focused']]))
mouse_button = gui.Button(sc, [280, -320], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['mouse'], 30, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), colors['Button']['frame_color'])
joystick_button = gui.Button(sc, [0, -320], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['joystick'], 30, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), colors['Button']['frame_color'])
control_label = gui.Label(sc, [-750, -320], lang['choice_control_type'], colors['Label']['text_color'], 30)
plaese_restart_game = gui.Label(sc, [-780, 50], lang['please_restart_game'], colors['Label_2']['text_color'], 22)
language_label = gui.Label(sc, [-750, -120], lang['choice_language'], colors['Label']['text_color'], 30)
russian_button = gui.Button(sc, [0, -120], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], ("Русский", 30, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), colors['Button']['frame_color'])
english_button = gui.Button(sc, [-250, -120], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], ("English", 30, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), colors['Button']['frame_color'])

# Skin Selector
next_skin = gui.Button(sc, [0, 300], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], ('>', 40, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), (255,255,0))
back_skin = gui.Button(sc, [-150, 300], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], ("<", 40, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), (255,255,0))

backgound_lines_x = 32
backgound_lines_y = 18

# Game widgets
players_label = gui.Label(sc, [-780, -300], lang['players'], colors['Label']['text_color'], 25)
lenght_label = gui.Label(sc, [-780, -260], lang['lenght'], colors['Label']['text_color'], 25)
exit_button_game = gui.Button(sc, [-780, -440], ['wrap_content', 'wrap_content'], colors['Button']['background_color'], (lang['exit'], 50, [colors['Button']['text_color'], colors['Button']['text_color_focused']]), (255,255,0))

#Settings configurations
load_data = default_config
if data['control'] == 'mouse':
    controlType = 'mouse'
    mouse_button.select()
else:
    controlType = 'joystick'
    joystick_button.select()

if data['lang'] == 'english':
    language = 'english'
    english_button.select()
else:
    language = 'russian'
    russian_button.select()
    
# Game config
camera = control.Camera(sc)
game = control.draw(camera)

# Menu config
connecting_timeout = 5 #seconds
connecting_timer = 0
connecting = False
init = False
connected = False

# Animation background
anim_count = 2
anim_dir = 1
anim_values = [2, 2.4]

# Joystick
angle = 0
pressed = False

# Game data
world_info = {'x_lines': 50,
              'y_lines': 50, 
              'size': 10,
              'r': 7,
              'food_r': 5,
              'players': 23,
              'rect': [0,0,0,0],
              'viewer': 0}
players = {}
food = {}
frame = 0 # For skin selector animation
while True:
    clock.tick(180)
    frame += 1
    pg.display.set_caption('Python IO')
    if screen == 1:
        # Animation
        if anim_dir:
            anim_count += 0.001
        else:
            anim_count -= 0.001
        if anim_count > anim_values[1]:
            anim_dir = 0
        if anim_count < anim_values[0]:
            anim_dir = 1
        camera.zoom(anim_count)
        sc.fill(colors['Background']['menu_color'])
        for i in range(20):
            game.line(colors['Background']['menu_line_vertical'], i*100-800*1.2, -450, i*100-800*1.5,450)
            game.line(colors['Background']['menu_line_horizontal'], -800, i*100-450*1.3, 800, i*100-450*2)

        for ev in pg.event.get():
            if start_button.get_pressed(ev) and not connecting:
                connecting_timer = time.time()
                connecting = True
                pressed = False

            if settings_button.get_pressed(ev):
                screen = 2
            
            if ev.type == pg.QUIT or exit_button.get_pressed(ev):
                pg.quit()
                exit()

        if connecting:
            message_label.text = lang['connecting']
            message_label.blit()
            try:
                connecting = False
                message_label.text = lang['connection_error']
                print(lang['connection_error']) 
                client = Client('127.0.0.1', 50000, name, lang, skin_id)
                init = True
            except:pass

        if init:
            log = client.init()
            if log == 'Connected!':
                message_label.text = lang['connected']
                screen = 3
                init = False
                connected = True
                camera.zoom(0.5)
            else:
                message_label.text = log

        settings_button.blit()
        start_button.blit()
        python_io_label.blit()
        message_label.blit()
        developer_label.blit()
        exit_button.blit()
        fps_label.text = str(int(clock.get_fps())) + ' FPS'
        fps_label.blit()

    elif screen == 3 and connected:
        sc.fill((0,0,0))
        camera.scroll_z = 2.2
        for i in range(world_info["x_lines"]):
            game.line((80, 80, 80), i*(1000*world_info['size'])/world_info["x_lines"], 0, i*(1000*world_info['size'])/world_info["x_lines"],1000*world_info['size'])
            game.line((80, 80, 80), 0, i*(1000*world_info['size'])/world_info["y_lines"], 1000*world_info['size'], i*(1000*world_info['size'])/world_info["y_lines"])

        a = client.get_data()
        try:
            if players == {}:
                players = a['players']
        except:pass

        if a == 'disconnect':
            client.socket.close()
            screen = 1
            camera.scroll([0, 0])
            connected = False
        else:
            if a:
                if a == '#READY?':
                    client.send_data('#YES!')
                try:
                    players.update(a['players'])
                    world_info.update(a['info'])
                    food.update(a['food'])
                    camera.scroll(control.camera_controller(players[world_info['viewer']]['pos'], camera, 10))
                
                    players_label.text = lang['players'] + str(world_info['players'])
                except Exception as e:print('exception in 180 line: ' + str(e))
                
            try:
                for f in food['f']:
                    game.circle(colors['Food'][int(f[0]%8)], f[0], f[1], world_info['food_r']/2, 0)
            except Exception as e:print('exception in 186 line: ' + str(e)) 

            dep = -1
            for i in players.keys():
                try:
                    if not players[i]['ready'] == 6 and i in list(a['players'].keys()):
                        Snake(players[i], game, game_font)

                    else:
                        message_label.text = lang['game_over']
                        dep = i
                    if i == world_info['viewer']:
                        lenght_label.text = lang['lenght'] + str(len(players[i]['tail']))
                except:pass
            if dep != -1:
                del players[i]
            keys = pg.key.get_pressed()
            if keys[pg.K_UP]:
                camera.scroll_z -= 0.01
            elif keys[pg.K_DOWN]:
                camera.scroll_z += 0.01
        for ev in pg.event.get():
            if ev.type == pg.QUIT:
                pg.quit()
                exit()
            if ev.type == pg.MOUSEBUTTONDOWN:
                pressed = True
            
            elif ev.type == pg.MOUSEBUTTONUP:
                pressed = False

            if exit_button_game.get_pressed(ev):
                camera.zoom(1)
                camera.scroll([0, 0])
                client.send_data('disconnect')
                screen = 1
                food = {}
                players = {}
                world_info = {'x_lines': 50,
                                'y_lines': 50, 
                                'size': 10,
                                'r': 7,
                                'food_r': 5,
                                'players': 23,
                                'rect': [0,0,0,0],
                                'scroll_z': 1,
                                'viewer': 0}
                client.socket.close()
            
        exit_button_game.blit()
        lenght_label.blit()
        players_label.blit()
        fps_label.text = str(int(clock.get_fps())) + ' FPS'
        fps_label.blit()

        mouse = pg.mouse.get_pos()
        if controlType == 'mouse':
            cur_mouse = mouse[0]-control.wx(800), mouse[1]-control.hy(450)
            angle = math.atan2(cur_mouse[0], cur_mouse[1]) + math.radians(180)
            log1 = client.send_data(int(math.degrees(angle)))

        elif controlType == 'joystick':
            pg.draw.circle(sc, (20, 20, 20), (control.w(-600), control.h(250)), control.dp(80))
            if pressed:
                cur_mouse = mouse[0]-control.w(-600), mouse[1]-control.h(250)
                angle = math.atan2(cur_mouse[0], cur_mouse[1]) + math.radians(180)
                if math.sqrt(pow(cur_mouse[0], 2) + pow(cur_mouse[1], 2)) < control.dp(60):
                    pg.draw.circle(sc, (45, 24, 205), mouse, control.dp(25))
                else:
                    pg.draw.circle(sc, (45, 24, 205), (control.w(-600) + math.sin(angle-3.14) * control.dp(60), control.h(250) + math.cos(angle-3.14) * control.dp(60)), control.dp(25))
            else:
                pg.draw.circle(sc, (45, 24, 205),(control.w(-600), control.h(250)), control.dp(25))
            log1 = client.send_data(int(math.degrees(angle)))

        if log1 != None:
            message_label.text = str(log1)
        if log1 == lang['bad_connect']:
            screen = 1
            client.socket.close()
            camera.scroll([0, 0])
            connected = False
        
    elif screen == 2:
            sc.fill(colors['Background']['settings_color'])
            # Animation
            if anim_dir:
                anim_count += 0.001
            else:
                anim_count -= 0.001
            if anim_count > anim_values[1]:
                anim_dir = 0
            if anim_count < anim_values[0]:
                anim_dir = 1
            camera.zoom(anim_count)
            for i in range(20):
                game.line(colors['Background']['settings_line_vertical'], i*100-800*1.1, -450, i*100-800*1.7,450)
                game.line(colors['Background']['settings_line_horizontal'], -800, i*100-450*1.3, 800, i*100-450*2)
            for ev in pg.event.get():
                if back_skin.get_pressed(ev):
                    skin_id -= 1
                if next_skin.get_pressed(ev):
                    skin_id += 1
                skin_id %= len(skins)
                if mouse_button.get_pressed(ev):                 
                    if controlType == 'joystick':
                        mouse_button.select()
                        joystick_button.select()
                    controlType = 'mouse'

                if joystick_button.get_pressed(ev):
                    if controlType == 'mouse':
                        mouse_button.select()
                        joystick_button.select()
                    controlType = 'joystick' 

                if english_button.get_pressed(ev):              
                    if language == 'russian':
                        english_button.select()
                        russian_button.select()
                    language = 'english'

                if russian_button.get_pressed(ev):
                    if language == 'english':
                        english_button.select()
                        russian_button.select()
                    language = 'russian'  
                if back_button.get_pressed(ev):
                    with open('config.json', 'w') as file:
                        json.dump({'control': controlType, 'lang': language, 'skin_id': skin_id}, file)
                    screen = 1

                if ev.type == pg.QUIT:
                    pg.quit()
                    exit()

            mouse_button.blit()
            joystick_button.blit()
            control_label.blit()
            language_label.blit()
            russian_button.blit()
            english_button.blit()
            plaese_restart_game.blit()
            back_button.blit()
            back_skin.blit()
            next_skin.blit()
            skin_view(skin_id, sc, [0, 230], 15, frame)

    pg.display.update()
