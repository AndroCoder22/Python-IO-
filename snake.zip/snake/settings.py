import random

name = "Player " + str(random.randrange(1000, 10000))

WIDTH = 1366
HEIGHT = 768
