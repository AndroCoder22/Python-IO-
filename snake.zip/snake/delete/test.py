""" import pygame as pg
from control import Camera, Game
pg.init()
WIDTH, HEIGHT = 800, 450
def w(value):
    return (WIDTH/1600)*(value+800)

def h(value):
    return (HEIGHT/900)*(value+450)

def dp(value):
    return ((WIDTH)/900)*value

class object:
    def __init__(self, sc):
        self.sc = sc
        self.scroll_x = 0
        self.scroll_y = 0
        self.scroll_z = 0
        
    def circle(self, col, x, y, r):
        #pg.draw.circle(self.sc, col, (w(self.scroll_z*x-self.scroll_x-(r*2)), h(self.scroll_z*y-self.scroll_y-(r*2))), dp(r)*self.scroll_z)
        pg.draw.circle(self.sc, col, (w(self.scroll_z*x-self.scroll_x), h(self.scroll_z*y-self.scroll_y)), dp(r)*self.scroll_z)
    def rectangle(self, col, x, y, wp, hp):
        pg.draw.rect(self.sc, col, (w(self.scroll_z*x-self.scroll_x), h(self.scroll_z*y-self.scroll_y), dp(wp)*self.scroll_z, dp(hp)*self.scroll_z))
    
    def line(self, col, x1, y1, x2, y2):
        pg.draw.line(self.sc, col, (w(x1*self.scroll_z-self.scroll_x), h(y1*self.scroll_z-self.scroll_y)), (w(x2*self.scroll_z-self.scroll_x), h(y2*self.scroll_z-self.scroll_y)))
    
    def set_scroll(self, x, y):
        self.scroll_x = x
        self.scroll_y = y
    def zoom(self, val):
        self.scroll_z = val
        

sc = pg.display.set_mode((WIDTH, HEIGHT), pg.RESIZABLE)
clock = pg.time.Clock()
camera = Camera(sc)
game = Game(camera)

x, y, z = 0,0,1
while True:
    clock.tick(60)
    sc.fill((24,24,34))
    a = game.circle((255,255,255), 0, 0, 100)
    b = game.circle((255,25,255), x, y, 50)
    game.line((100,100,100), a.x, a.y, b.x, b.y)
    if a.collidecircle(b):
        print(1)
    else:
        print(0)
 
    
    for ev in pg.evcent.get():
        if ev.type == pg.QUIT:
            exit()
        if ev.type == pg.VIDEORESIZE:
            sc = pg.display.set_mode((ev.w, ev.h), pg.RESIZABLE)
            HEIGHT = ev.h
            WIDTH = ev.w
 
    k = pg.key.get_pressed()
    if k[pg.K_UP]:
        y -= 3
    if k[pg.K_DOWN]:
        y += 3
    if k[pg.K_LEFT]:
        x -= 3
    if k[pg.K_RIGHT]:
        x += 3
    if k[pg.K_w]:
        z += 0.005
    if k[pg.K_s]:
        z -= 0.005
    camera.scroll(x, y)
    amera.zoom(z)
"""
class namew:
    def start(self):
        print("hiiii")

class n(namew):
    def start(self):
        print(23123)
    
a = namew()
a.start()