import socket
import json
import time
import pickle

class Client:
    def __init__(self, ip, port, user_name, lang, skin_id):
        self.i = 1
        self.errors = 0
        self.lang = lang
        self.initialization = False
        self.o = ''
        self.ping = 0
        self.ping_time = 0
        self.user_name = user_name
        self.skin_id = skin_id
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print(lang['connecting'])
        self.socket.setblocking(1)
        self.socket.connect((ip, port))

    def get_data(self):
        try: 
            self.ping = time.time() - self.ping_time
            data = pickle.loads(self.socket.recv(102040))
            return data
        except: 
            pass

    def init(self):
        if self.i == 1:
            self.send_data([str(self.user_name), self.skin_id])
        elif self.i == 2:
            self.o = self.get_data()
        elif self.i == 3:
            if self.o == '#READY?':
                self.send_data('#YES!')  
                self.initialization = True
                print(self.lang['connected'])
            else:   
                return self.o
        if self.initialization:
            return 'Connected!'
        else:
            self.i += 1
        return ''

    def send_data(self, data):
        try:
            self.ping_time = time.time()
            self.socket.send(pickle.dumps(data))
            self.errors = 0
        except:
            self.errors += 1
            if self.errors >= 500:
                return self.lang['bad_connect']