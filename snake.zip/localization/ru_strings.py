str = {
    'start_game': 'Начать игру',
    'settings': 'Параметры',
    'choice_control_type': 'Выберете тип управления:',
    'choice_language': 'Выберете язык: ',
    'mouse':'Мышь',
    'joystick':'Джойстик',
    'back': '< Сохранить',
    'connecting': 'Подключение...',
    'connected': 'Подключено!' ,
    'connection_error': 'Ошибка подключения.',
    'game_over': 'Игра окончена }:',
    'developer': 'Разработчик: Илья',
    'please_restart_game': 'Пожалуйста перазапустите игру для применения языковых настроек',
    'exit': 'Выйти',
    'players': 'Игроков: ',
    'bad_connect': 'Нестабильное соединение ._.',
    'lenght': 'Длина: '
    }