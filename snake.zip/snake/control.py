from settings import *
import pygame as pg
import math
class Camera:
    def __init__(self, sc):
        self.sc = sc
        self.scroll_x = 0
        self.scroll_y = 0
        self.scroll_z = 1
        
    def scroll(self, s):
        self.scroll_x = s[0]
        self.scroll_y = s[1]
    def zoom(self, val):
        val = val ** val/4
        if val >= 2.4:
            val = 2.4
        self.scroll_z = val
        """ self.scroll_z = max(0.23, val)
        self.scroll_z = min(9.99, val) """

    
class draw:
    def __init__(self, camera):
        self.camera = camera
        self.screen = camera.sc
        
    def circle(self, col, x, y, r, stroke = 0):
        return Circle(self.screen, self.camera, col, x, y, r, stroke)
        
    def rect(self, col, x, y, w, h, hw, rounded):
        return Rectangle(self.screen, self.camera, col, x, y, w, h, hw, rounded)
        
    def line(self, col, x1, y1, x2, y2, size = 1):
        return Line(self.screen, self.camera, col, x1, y1, x2, y2, size)

    def linelayer2(self, col, x1, y1, x2, y2):
        return LineLayer2(self.screen, self.camera, col, x1, y1, x2, y2)

    def text(self, text, font, pos, color):
        blit(self.screen, self.camera, font.render(text, 100, color), pos)
 

class Circle:
    def __init__(self, screen, cam, col, x, y, r, stroke):
        self.r = r
        self.x = x
        self.y = y
        pg.draw.circle(screen, col, (w(cam.scroll_z*x-cam.scroll_x), h(cam.scroll_z*y-cam.scroll_y)), dp(r)*cam.scroll_z, stroke)

    def collidecircle(self, circle):
        if math.sqrt(pow(w(circle.x) - w(self.x), 2) + pow(h(circle.y) - h(self.y), 2)) < dp(self.r + circle.r):
            return True
        else:
            return False

    def collidecircle_fromvalues(self, x, y, r):
        if math.sqrt(pow(w(x) - w(self.x), 2) + pow(h(y) - h(self.y), 2)) < dp(self.r + r):
            return True
        else:
            return False
    
class Rectangle:
    def __init__(self, screen, cam, col, x, y, wp, hp, hw = 0, rounded = 1):
        pg.draw.rect(screen, col, (w(cam.scroll_z*x-cam.scroll_x), h(cam.scroll_z*y-cam.scroll_y), dp(wp*cam.scroll_z), dp(hp*cam.scroll_z)), hw, rounded, rounded, rounded, rounded)

class Line:
    def __init__(self, screen, cam, col, x1, y1, x2, y2, size):
        pg.draw.line(screen, col, (w(x1*cam.scroll_z-cam.scroll_x), h(y1*cam.scroll_z-cam.scroll_y)), (w(x2*cam.scroll_z-cam.scroll_x), h(y2*cam.scroll_z-cam.scroll_y)), size)
        
class LineLayer2:
    def __init__(self, screen, cam, col, x1, y1, x2, y2):
        pg.draw.line(screen, col, (w(x1*cam.scroll_z-cam.scroll_x/2), h(y1*cam.scroll_z-cam.scroll_y/2)), (w(x2*cam.scroll_z-cam.scroll_x/2), h(y2*cam.scroll_z-cam.scroll_y/2)))

class blit:
    def __init__(self, screen, cam, widget, pos):
        screen.blit(widget, ((w(pos[0]*cam.scroll_z-cam.scroll_x), h(pos[1]*cam.scroll_z-cam.scroll_y))))

def w(value):
    return (WIDTH/1600)*(value+800)

def h(value):
    return (HEIGHT/900)*(value+450)

def wx(value):
    return int((WIDTH/1600)*value)

def hy(value):
    return int((HEIGHT/900)*value)


def wr(value):
    return (WIDTH/1600)/(value-800)

def hr(value):
    return (HEIGHT/900)/(value-450)


def dp(value):
   # if WIDTH > HEIGHT:
    return int((WIDTH/900)*value)
    #else:
      #  return (HEIGHT/900)*value

def camera_controller(pos, camera, speed):
    scroll_x = camera.scroll_x
    scroll_y = camera.scroll_y
    if pos[0]*camera.scroll_z - camera.scroll_x != 0:
        scroll_x += (pos[0]*camera.scroll_z-camera.scroll_x)/speed
    
    if pos[1]*camera.scroll_z - camera.scroll_y != 0:
        scroll_y += (pos[1]*camera.scroll_z-camera.scroll_y)/speed
    return [scroll_x, scroll_y]

