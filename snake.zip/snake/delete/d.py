import pygame as pg 
import math
width, height = 600, 600
pg.init()
sc = pg.display.set_mode((width, height))
clock = pg.time.Clock()

class Player:
    def __init__(self):
        self.player_angle = 0

    def update(self, angle):
        if angle > self.player_angle:
            self.player_angle += 0.04

        if angle < self.player_angle:
            self.player_angle -= 0.04

        pg.draw.circle(sc, (255, 255, 25), (width/2, height/2), 50)
        pg.draw.circle(sc, (0, 255, 255), (width/2+math.sin(self.player_angle+1)*20, height/2+math.cos(self.player_angle+1)*20), 7)
        pg.draw.circle(sc, (0, 255, 255), (width/2+math.sin(self.player_angle-1)*20, height/2+math.cos(self.player_angle-1)*20),7)
player = Player()
while True:
    clock.tick(60)
    sc.fill((0,0,0))
    for ev in pg.event.get():
        if ev.type == pg.QUIT:
            exit()

    mouse_angle = math.atan2(pg.mouse.get_pos()[0]-(width/2), pg.mouse.get_pos()[1]-(height/2))
    player.update(mouse_angle)
    pg.display.update()
