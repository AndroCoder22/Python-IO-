str = {
    'start_game':'Start game',
    'settings':'Options',
    'choice_control_type': 'Choice control type:',
    'choice_language': 'Choice language: ',
    'mouse': 'Mouse',
    'joystick': 'Joystick',
    'back': '< Save',
    'connecting': 'Connecting...',
    'connected': 'Connected!' ,
    'connection_error': 'Connection error.',
    'game_over': 'Game over }:',
    'developer': 'Developer: Ilya',
    'please_restart_game': 'Please restart the game to apply language settings',
    'exit': 'Exit',
    'players': 'Players:',
    'bad_connect': 'Unstable connection ._.',
    'lenght': 'lenght: '
    }