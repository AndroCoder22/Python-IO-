import pygame as pg 
import math
from random import randrange as rr 
from control import Camera, draw, w, h, dp, wx, hy
from settings import *

pg.init()
sc = pg.display.set_mode((WIDTH, HEIGHT))
clock = pg.time.Clock()


#server = client.Client('127.0.0.1', 35000, 'ilya')

#joystick
istouch = False
mouse2 = (-1000, -1000)
angler = 1
angle = 1

#World
scroll_x, scroll_y, scroll_z = 0, 0, 1
eat = []
eat_p = 100
eat_colors = []
generate = False
world_size = 2
x_line = 20
y_line = 20

#player
head = [1000, 1000]
tail_x_1 = []
tail_y_1 = []
pos_x = []
pos_y = []
velosity = [1, 1]

size = 50
snake_lenght = size
snake_height = size/10
snake_lenght2 = snake_lenght


snake_speed = 3

#SKINS
RUS_SKIN = {
    'colors': [[7,255,255], [0,0,255], [255,0,0], [123,123,213], [0,0,123]],
    'lenght': 50
}
def avs(array):
    result = sum(array)
    result /= len(array)
    return result
current_skin = RUS_SKIN
skin = []

camera = Camera(sc)
game = draw(camera)
rad = 3.14
camera.scroll_z = 2
def camera_scrolling():
    global scroll_x, scroll_y
    if head[0]*camera.scroll_z - camera.scroll_x != 0:
        scroll_x += (head[0]*camera.scroll_z-camera.scroll_x)/20
    
    if head[1]*camera.scroll_z - camera.scroll_y != 0:
        scroll_y += (head[1]*camera.scroll_z-camera.scroll_y)/20
        
    camera.scroll([scroll_x, scroll_y])

def food_collide(pos, rad):
    if pos[0]+rad > a and pos[0]-rad < c and pos[1]+rad > b and pos[1]-rad < d:
        return True
    else:
        return False


def snake_controller():
    global angle, angler, dead
   # angler = 3.14*angler/3.14
    #dif = angler-3.14 - angle
    """ if angle > 0:
        angle = angle
    else:
        angle = -3.14-angle """
    #if (dif < 0 and dif > -3.14 or dif > 3.14):
        #angle += 0.05
      #  angle %= 9
    #elif (dif > 0 and dif < 3.14 or dif < -3.14):
        #angle -= 0.05
    angle = angler-3.14
    global head
    if head[0] < 0+snake_height:
        dead = True  #head[0] += -math.sin(math.radians(angle-180))*snake_speed*10
    elif head[0] > 1000*world_size-snake_height:
        dead = True#head[0] += -math.sin(math.radians(angle-180))*snake_speed*10
    else:
       # dead = True
        head[0] += math.sin(angle)*snake_speed
    
    if head[1] < 0+snake_height:
        dead = True#head[1] += -math.cos(math.radians(angle-180))*snake_speed*10
    elif head[1] > 1000*world_size-snake_height:
        dead = True# head[1] += -math.cos(math.radians(angle-180))*snake_speed*10
    else:
        #dead = True
        head[1] += math.cos(angle)*snake_speed
    
def generate_eda(ed, arr, intensity, incerate): #[[x,x,x,x,,x,x], [y,y,y,y,y,,yy,y,]]
    for i in range(int(len(arr[0])/intensity)):
        ed.append([arr[0][i*intensity] + (rr(incerate*2)-(incerate/2)), arr[1][i*intensity] + (rr(incerate*2)-(incerate/2))])
    return ed
ap = 0
apx = 0
tick = 0  
glass = []
eda = False
zraz = glass
ed = []
col = [rr(255), rr(255), rr(255)]
while 1:
    clock.tick(60)
    sc.fill((20, 20, 20))
    mouse = pg.mouse.get_pos()
    for i in range(3):
        col[i] += 1
        col[i] %= 255

    if not generate:
        dead = False
        for i in range(eat_p):
            eat.append([rr(0, 1000 * world_size), rr(0, 1000 * world_size)])
            eat_colors.append([rr(100, 255), rr(100, 255), rr(100, 255)])
        for l in range(len(current_skin['colors'])):
            for t in range(int(current_skin['lenght']/len(current_skin['colors']))):
                sk = [current_skin['colors'][l][0]+rr(30)-15, current_skin['colors'][l][1]+rr(30)-15, current_skin['colors'][l][2]+rr(30)-15]
                for f in range(3):
                    if sk[f] > 255: sk[f] = 255
                    if sk[f] < 0: sk[f] = 0
                skin.append(sk)
        generate = True


    if generate:
        tail_x_1.insert(0, head[0])
        tail_y_1.insert(0, head[1])
        tail_x = tail_x_1[0:int(snake_lenght*snake_lenght/30):int((snake_lenght/30))]#:int(snake_lenght*(snake_height/2))]
        tail_y = tail_y_1[0:int(snake_lenght*snake_lenght/30):int((snake_lenght/30))]
        a = min(tail_x)
        b = min(tail_y)
        c = max(tail_x)
        d = max(tail_y)
        
        for i in range(x_line):
            game.line((80, 80, 80), i*(1000*world_size)/x_line, 0, i*(1000*world_size)/x_line,1000*world_size)
            game.line((80, 80, 80), 0, i*(1000*world_size)/y_line, 1000*world_size, i*(1000*world_size)/y_line)
        game.rect((0, 0, 0), a, b, c-a*ap, d-b*ap, 0, 0)
        #players, sworld = server.get_data()
        #print(players)
        #head[0] = players[0]['x']; head[1] = players[0]['y']
        #player_rect = pg.Rect((w(head[0]-snake_height-scroll_x)*scroll_z, h(head[1]-snake_height-scroll_y)*scroll_z), (dp(snake_height*2)*scroll_z, dp(snake_height*2)*scroll_z))
        if ed != []:
            for i in range(len(ed)):
                try:
                    eda_rect = game.circle((255, 0, 0 ), ed[i][0], ed[i][1], 7)
                    if eda_rect.collidecircle_fromvalues(head[0], head[1], snake_height):
                        snake_lenght2 += 50
                        snake_height += 0.1
                        ed.pop(i)
                except:pass
        for i in range(eat_p):
            eat_rect = game.circle(eat_colors[i],eat[i][0], eat[i][1], 7)
        #if food_collide(eat[i], 7):
            #eat[i] = [rr(0, w(1600)*world_size), rr(0, h(900)*world_size)]
            if eat_rect.collidecircle_fromvalues(head[0], head[1], snake_height):
                snake_lenght2 += 50
                snake_height += 0.1
                eat[i] = [rr(0, w(1600)*world_size), rr(0, h(900)*world_size)]
        
        for ev in pg.event.get():
            if ev.type == pg.QUIT:
                exit()

            if ev.type == pg.MOUSEBUTTONDOWN:
                istouch = True
                mouse2 = mouse 

            elif ev.type == pg.MOUSEBUTTONUP:
                istouch = False	
                

        if True:

            #pg.draw.circle(sc, (100,100,100, 50), mouse2, dp(70))
            cur_mouse = mouse[0]-wx(800), mouse[1]-hy(450)
            angler = math.atan2(cur_mouse[0], cur_mouse[1]) + math.radians(180)
            #distance  = math.sqrt(pow(cur_mouse[0], 2) + pow(cur_mouse[1], 2))
            current_angle = angler
           # joy_pos = mouse2
            #if distance > dp(80):
                #si = math.sin(angler)
               # co = math.cos(angler)
               # joy_pos = (math.degrees(si)*dp(1.4)+mouse2[0], math.degrees(co)*dp(1.4)+mouse2[1])
               # distance = w(80)
           # else:
                #joy_pos = mouse
        
           # pg.draw.circle(sc, (234,234,234,50), joy_pos, dp(30))
    
        glass = [[math.sin(angle+1)*(snake_height)+head[0], math.cos(angle+1)*(snake_height) + head[1]], [math.sin(angle-1)*(snake_height)+head[0], math.cos(angle-1)*(snake_height) + head[1]]]
        zraz = [[math.sin(angler)*(snake_height/3)+glass[0][0], math.cos(angler)*(snake_height/3) +glass[0][1]], [math.sin(angler)*(snake_height/3)+glass[1][0], math.cos(angler)*(snake_height/3)+glass[1][1]]]

    
        """ if int(snake_lenght2/10) >= int(snake_lenght/10):
            snake_lenght += 0.1
        elif int(snake_lenght2/10) <= int(snake_lenght/10):
            snake_lenght -= 0.1 """
        
        tick += 1
        if tick == 100:
            tick = 0
            #snake_height += 1
        if not dead:
            snake_controller()
            camera_scrolling()
        
        if not dead:
           # fk = 0
            for sn in range(int(snake_lenght), 0, -1):
                try:
                  #  game.circle((46, 244, 100), tail_x[sn], tail_y[sn], snake_height+1, 1)
                    
                    #if sn < snake_lenght-(snake_lenght/2):
                        #fk += 0.1
                    #game.rect(skin[int(sn % current_skin['lenght'])], tail_x[sn], tail_y[sn], snake_height, snake_height, 0, 0)
                    game.circle(skin[int(sn % current_skin['lenght'])], tail_x[sn], tail_y[sn], snake_height)
                        #game.circle(skin[int(sn/4 % current_skin['lenght'])], tail_x[sn], tail_y[sn], snake_height-(sn/2-(snake_lenght/2.2)))
                    
                    
                    for i in range(4):
                        tail_x[sn] = avs([tail_x[sn-1], tail_x[sn+1]])# tail_x[sn+1]])# tail_x[sn+2]])
                        tail_y[sn] = avs([tail_y[sn-1], tail_y[sn+1]])#, tail_y[sn+1]]) #tail_y[sn+2]])
                except:
                    game.circle((255,255,255), head[0], head[1], snake_height)
                    #game.rect(skin[int(sn % current_skin['lenght'])], head[0], head[1], snake_height, snake_height, 0, 0)
            
            #game.circle((46, 244, 100), tail_x[0], tail_y[0], snake_height+2) 
            game.circle(current_skin['colors'][0], head[0], head[1], snake_height)
            for i in range(2):
                game.circle((0,0,0), glass[i-1][0], glass[i-1][1], snake_height/2)
                game.circle((255,255,255), zraz[i-1][0], zraz[i-1][1], snake_height/4)
            
            keys = pg.key.get_pressed()
            if keys[pg.K_UP]:
                ap -= 0.01
            elif keys[pg.K_DOWN]:
                ap += 0.01
            
            if keys[pg.K_UP]:
                apx -= 0.01
            elif keys[pg.K_DOWN]:
                apx += 0.01

            if round(snake_height/20, 3) > round(scroll_z, 3):
                scroll_z += 0.0004
            elif round(snake_height/20, 3) < round(scroll_z, 3):
                scroll_z -= 0.0004
            
            if round(snake_lenght2, 2) > round(snake_lenght, 2):
                snake_lenght += 0.02
            elif round(snake_lenght2, 2) < round(snake_lenght, 2):
                snake_lenght -= 0.02
            
        #  print(scroll_z)
            pg.display.set_caption(' ' + str(round(angle, 1)) + '                          ' + str(round(angler, 1)))
            camera.zoom(3.1-scroll_z)
        
    
    if dead:
        ed = generate_eda(ed, [tail_x_1[:int(snake_lenght)], tail_y_1[:int(snake_lenght)]], 10, 20)
        head = [rr(-1000, 1000), rr(-1000, 1000)]
        tail_x_1 = []
        tail_y_1 = []
        dead = False
        print(ed)
    pg.display.update()
