from skins import skins
import math
class Snake:
    def __init__(self, snake_info, game, font):
        for i in range(len(snake_info['tail'])-1, 0, -1):
            game.circle(skins[snake_info['skin'] % len(skins)][0][int(abs(i-len(snake_info['tail'])) % skins[snake_info['skin']][1])], snake_info['tail'][i][0], snake_info['tail'][i][1], snake_info['size']/8)
        
        game.circle(skins[snake_info['skin'] % len(skins)][0][int(abs(i-len(snake_info['tail'])) % skins[snake_info['skin']][1])], snake_info['pos'][0], snake_info['pos'][1], snake_info['size']/8)
        gs = [[math.sin(snake_info['angle']+1)*(snake_info['size']/10)+snake_info['pos'][0], math.cos(snake_info['angle']+1)*(snake_info['size']/10) + snake_info['pos'][1]], [math.sin(snake_info['angle']-1)*(snake_info['size']/10)+snake_info['pos'][0], math.cos(snake_info['angle']-1)*(snake_info['size']/10) + snake_info['pos'][1]]]
        zr = [[math.sin(snake_info['angle'])*(snake_info['size']/10/3)+gs[0][0], math.cos(snake_info['angle'])*(snake_info['size']/8/3) +gs[0][1]], [math.sin(snake_info['angle'])*(snake_info['size']/10/3)+gs[1][0], math.cos(snake_info['angle'])*(snake_info['size']/8/3)+gs[1][1]]]
        for i in range(2):
            game.circle((230, 207, 240), gs[i][0], gs[i][1], snake_info['size']/8/2)
            game.circle((30, 0, 10), zr[i][0], zr[i][1], snake_info['size']/8/4)

        game.text(snake_info['name'], font, [snake_info['pos'][0]-50, snake_info['pos'][1]-50], (255, 255, 255))
        