import socket
import time
import json
import pygame
import math
from random import randrange as rr

socket = socket.socket( socket.AF_INET, socket.SOCK_STREAM )
socket.bind(('127.0.0.1',10000))
#socket.setsockopt( socket.IPP,socket.TCP_NODELAY, 1)
socket.setblocking(0)
socket.listen(5)
server_ticks = 0
clock = pygame.time.Clock()


def create_world():
    for i in range(world['food_amount']):
        world['pos'].append([rr(0, WIDTH * world_size), rr(0, HEIGHT * world_size)])
        world['colors'].append([rr(100, 255), rr(100, 255), rr(100, 255)])

def accept_player():
    new_socket, addres = socket.accept()
    new_socket.setblocking(0)
    current_name = new_socket.recv(1024).decode()
    users_pos.append([rr(1000), rr(1000)])
    print(players)
while True:
    dt = clock.tick(120)
    server_ticks += 1
   # print(dt)
    if server_ticks >= 400/dt*10:
        server_ticks = 0
        print("accepting")
        try:
            #a, b = socket.accept()
            print(a)
        except:
            pass
    '''for i in range(len(players)):
        try:
            comand = players[i]['socket'].recv(1024).decode()
            players[i]['x'] += math.sin(float(comand))
            players[i]['y'] += math.cos(float(comand))
            #users_tails_x.insert(0, )
        except:
            pass
        try:
            players[i]['socket'].send(json.dumps({players}).encode('utf-8'))
        except:
            print("player " + str(players[i]['name']) + ' disconnected!')
            del players[i]
          
   
   # time.sleep(0.04)
#'''