import pygame as pg 
import math
import client
from random import randrange as rr 

WIDTH, HEIGHT = 1150, 650
def w(value):
    return (WIDTH/1600)*value

def h(value):
    return (HEIGHT/900)*value

    
pg.init()
sc = pg.display.set_mode((WIDTH, HEIGHT))
clock = pg.time.Clock()

#server
print('no serv')
server = client.Client('127.0.0.1', 35000, 'ilya')
print('yer serv')


#joystick
istouch = False
mouse2 = (-1000, -1000)
angler = 0

#World
scroll_x, scroll_y = 0, 0
eat = []
eat_p = 2000
eat_colors = []
generate = False
world_size = 10

#player
head = [100, 100]
tail_x = []
tail_y = []

snake_lenght = 2
snake_height = 20

snake_speed = 2

#SKINS
RUS_SKIN = {
    'colors': [[255,255,255], [0,0,255], [255,0,0], [123,123,213], [0,0,123]],
    'lenght': 50
}

current_skin = RUS_SKIN
skin = []

while 1:
    #clock.tick(60)
    sc.fill((20, 20, 20))
    pg.display.set_caption(str(int(clock.get_fps())))
    mouse = pg.mouse.get_pos()

    if not generate:
        for i in range(eat_p):
            eat.append([rr(0, WIDTH * world_size), rr(0, HEIGHT * world_size)])
            eat_colors.append([rr(100, 255), rr(100, 255), rr(100, 255)])
        for l in range(len(current_skin['colors'])):
            for t in range(int(current_skin['lenght']/len(current_skin['colors']))):
                sk = [current_skin['colors'][l][0]+rr(30)-15, current_skin['colors'][l][1]+rr(30)-15, current_skin['colors'][l][2]+rr(30)-15]
                for f in range(3):
                    if sk[f] > 255: sk[f] = 255
                    if sk[f] < 0: sk[f] = 0
                skin.append(sk)
        generate = True


    if generate:
        players, sworld = server.get_data()
        #print(players)
        head[0] = players[0]['x']; head[1] = players[0]['y']
        player_rect = pg.Rect((head[0]-snake_height-scroll_x, head[1]-snake_height-scroll_y), (snake_height*2, snake_height*2))
        for i in range(eat_p):
            eat_rect = pg.draw.circle(sc, eat_colors[i], (eat[i][0]-scroll_x, eat[i][1]-scroll_y), 20)
            if player_rect.colliderect(eat_rect):
                snake_lenght += 1
                snake_height += 0.1
                eat[i] = [rr(0, WIDTH*4), rr(0, HEIGHT*4)]

        for ev in pg.event.get():
            if ev.type == pg.QUIT:
                exit()

            if ev.type == pg.MOUSEBUTTONDOWN:
                istouch = True
                mouse2 = mouse 

            elif ev.type == pg.MOUSEBUTTONUP:
                istouch = False	

        if istouch:

            pg.draw.circle(sc, (100,100,100), mouse2, 100)
            cur_mouse = mouse[0] - mouse2[0], mouse[1] - mouse2[1]
            angler = math.atan2(cur_mouse[0], cur_mouse[1])
            distance  = math.sqrt(pow(cur_mouse[0], 2) + pow(cur_mouse[1], 2))
            current_angle = angler
            joy_pos = mouse2
            if distance > 80:
                si = math.sin(angler)
                co = math.cos(angler)
                joy_pos = (math.degrees(si)*1.4+mouse2[0], math.degrees(co)*1.4+mouse2[1])
                distance = 80
            else:
                joy_pos = mouse
        
            pg.draw.circle(sc, (234,234,234), joy_pos, 50)
        
        server.send_data(str(angler).encode('utf-8'))
        # head[0] += math.sin(angler)*snake_speed
        # head[1] += math.cos(angler)*snake_speed
        print(scroll_z)
        for sn in range(int(snake_lenght), 0, -1):
            try:
                pg.draw.circle(sc, skin[int(sn % current_skin['lenght'])], (tail_x[sn]-scroll_x, tail_y[sn]-scroll_y), int(snake_height))
            except:
                pg.draw.circle(sc, skin[int(sn % current_skin['lenght'])], (head[0]-scroll_x, head[1]-scroll_y), int(snake_height))
        pg.draw.circle(sc, current_skin['colors'][0], (head[0]-scroll_x, head[1]-scroll_y), int(snake_height))
        if head[0] - scroll_x != WIDTH/2:
            scroll_x += (head[0] - (scroll_x + WIDTH/2)) / 100
        if head[1] - scroll_y != HEIGHT/2:
            scroll_y += (head[1] - (scroll_y + HEIGHT/2)) / 100
        

        pg.display.update()
