import socket
import time
import json
import pygame as pg
import math
import control
from random import randrange as rr
import pickle


sc = pg.display.set_mode((4, 4))
#cam = control.Camera(sc)
#draw = control.draw(cam)



# Инициализация сервера
socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.bind(('127.0.0.1',50000))
socket.setblocking(0)
socket.listen(5)

# Классы 
def decoder(data):
    opens = None
    close = None
    for i in range(len(data)):
        if data[i] == '[':
            opens = i+1
        elif data[i] == ']' and opens != None:
            close = i
            break
        if data[0] == '<':
            return None
    return str(data[opens:close]).strip().split(' ')

class Player:
	def __init__(self, socket, name, position, skin, angle, ready):
		self.socket = socket
		self.angle = angle
		self.name = name
		self.pos = position
		self.skin = skin
		self.ready = ready
		self.disconnect = False
		self.errors = 0
		self.tails = []
		self.size = 150
		self.real_tails = []
		self.scroll_z = 2
		self.screen = [160*self.scroll_z, 90*self.scroll_z]
		self.target_size = self.size
		self.target_scroll_z = self.scroll_z
		self.round_positions = 1
		self.left = 0
		self.right = 0
		self.bottom = 0
		self.top = 0
		self.ticks = 0

	
	def update(self):
		if self.ready != 6:
			self.ticks += 1
			if ticks > 5: ticks = 0; self.snake_rect()
			self.angle = round(self.angle, 5)
			self.tails.insert(0, [round(self.pos[0], self.round_positions), round(self.pos[1], self.round_positions)])
			self.pos[0] = round(self.pos[0], self.round_positions); self.pos[1] = round(self.pos[1], self.round_positions)
			self.real_tails = self.tails[0:self.size*2:int(self.size/10/3)]
			self.target_scroll_z = self.size/10/2
			self.scroll_z = self.smooth_increase(self.scroll_z, self.target_scroll_z, 0.0004, 3)
			self.wall_collide_and_movement()
		
	def screen_size(self):
		self.screen = [1600*self.scroll_z, 900*self.scroll_z]
		self.screen_rect = pg.Rect(self.pos, self.screen)
		self.screen_rect.center = self.pos
		return self.screen_rect
	
	def snake_rect(self):
		self.left = min(self.real_tails[i][0] for i in range(len(self.real_tails)))
		self.right = max(self.real_tails[i][0] for i in range(len(self.real_tails)))
		self.bottom = max(self.real_tails[i][1] for i in range(len(self.real_tails)))
		self.top = min(self.real_tails[i][1] for i in range(len(self.real_tails)))

	def smooth_increase(self, value, value2, addition, fractions):
		if round(value2, fractions) > round(value, fractions):
			value += addition
		if round(value2, fractions) < round(value, fractions):
			value -= addition
		return value
	def wall_collide_and_movement(self):
		if self.pos[0] < 0+self.size/10:
			self.ready = 6
		elif self.pos[0] > 1000*arena-self.size/10:
			self.ready = 6
		else:
			self.pos[0] += math.sin(self.angle)*(delta_time/10)
		if self.pos[1] < 0+self.size/10:
			self.ready = 6
		elif self.pos[1] > 1000*arena-self.size/10:
			self.ready = 6
		else:
			self.pos[1] += math.cos(self.angle)*(delta_time/10)
	def get_pos(self):
		return [round(self.pos[0], self.round_positions), round(self.pos[1], self.round_positions)]
class Food:
	def __init__(self, x, y, r):
		self.x = x
		self.y = y
		self.r = r

	def collide_rect(self, rect):
		if self.x+self.r > rect.x and self.x-self.r < rect.right and self.y+self.r > rect.y and self.y-self.r < rect.bottom:
			return True
		else:
			return False
	def collide_snake(self, x, y, r):
		if math.sqrt(pow(x - self.x, 2) + pow(y - self.y, 2)) < (self.r + r):
			return True
		else:
			return False

# Переменные сервера
arena = 5 # x1000 pixels
clock = pg.time.Clock()
ticks = 0
players = []
food_amount = 100
food_r = 10
foods = [Food(rr(100, arena*1000 - 100), rr(100, arena*1000 - 100), food_r) for i in range(food_amount)]
while True:
	delta_time = clock.tick(100)
	ticks += 1
	for ev in pg.event.get():
		if ev.type == pg.QUIT:
			exit()
	pg.display.set_caption(str(clock.get_fps()))

	# Получение команд от игроков
	if ticks == 400:
		ticks = 0
		try:
			new_socket, addres = socket.accept()
			new_socket.setblocking(0)
			players.append(Player(new_socket, '', [100, 100], 1, rr(6), 0))
			print(1)
		except: pass
	
    # Обработка команд от игроков
	zp = -1
	for i in range(len(players)):
		
		try:
			#print(players[i].socket.recv(128).decode())
			if players[i].ready == 0:
				players[i].name = str(pickle.loads(players[i].socket.recv(128)))
				print('name ' + players[i].name)
				players[i].ready = 1

			if players[i].ready == 1 and pickle.loads(players[i].socket.recv(512)) == "#YES!":
				players[i].ready = 7
				print('ready')

			if players[i].ready == 7:
				data = pickle.loads(players[i].socket.recv(128))
				if data == 'disconnect':
					zp = i
				else:
					players[i].angle = math.radians(int(data)-180)
	
		except: pass
		if zp >= 0:
			print('disc')
			del players[zp]

    # Обновление игрового поля
	for i in range(len(players)):
		players[i].update()
    # Отправка команд игрокам
	dep = -1
	for i in range(len(players)):
		#print(i)
		try:
			if players[i].ready == 1:
				players[i].socket.send(pickle.dumps('#READY?'))
			elif  players[i].ready == 7 or players[i].ready == 6:
				dt = {'players': {}, 'info': {}, 'food': {}}
				for j in range(len(players)):
					dt['players'].update({j: {'pos': players[j].get_pos(), 'name': players[j].name, 'angle': players[j].angle, 'tail': players[j].real_tails, 'size': players[j].size, 'ready': players[j].ready}}) 
				f = []
				de = False
				for g in range(len(foods)):
					if foods[g].collide_rect(players[i].screen_size()):
						f.append([foods[g].x, foods[g].y])
						if foods[g].collide_snake(players[i].pos[0], players[i].pos[1], players[i].size/10):
							players[i].size += 1
							de = g
				if de:
					foods.remove(foods[de])
				""" if players[i].ready == 6:
					dt['info'].update({'viewer': i, 'size': arena, 'players': len(players), 'scroll_z': players[i].scroll_z, 'food_r': food_r,'r': 6})
				else: """
				dt['info'].update({'viewer': i, 'size': arena, 'players': len(players), 'scroll_z': players[i].scroll_z, 'food_r': food_r})
				dt['food'].update({'f': f})
				players[i].socket.send(pickle.dumps(dt))
				if players[i].ready == 6:
					players[i].errors += 1

				else:
					players[i].errors = 0
		except Exception as e:
			players[i].errors += 1
		if players[i].errors > 490:
			players[i].disconnect = True
		if players[i].errors > 500:
			try:
				players[i].socket.send(pickle.dumps('disconnect'))
			except: pass
			dep = i
	if dep >= 0:
		print('dis')
		del players[dep]
	