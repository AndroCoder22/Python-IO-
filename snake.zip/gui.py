import pygame as pg
from control import *
pg.init()

class Button:
	def __init__(self, sc, pos, size, color, text, select = None):
		self.con = sc
		self.pos = pos
		self.size = size
		if size[0] == "wrap_content":
			self.size[0] = text[1]*len(text[0])*1.1
		if size[1] == "wrap_content":
			self.size[1] = text[1]*2

		self.one_color = color[0]
		self.two_color = color[1]
		self.color = self.one_color
		self.text = text
		self.text_color = text[2]
		self.rect = pg.Rect((w(self.pos[0]), h(self.pos[1])), (wx(self.size[0]), hy(self.size[1])))
		self.mouse = pg.mouse.get_pos()
		self.focused = False
		self.round = 20
		self.select_color = select
		self.selected = False

		self.font = pg.font.Font("MonospaceOblique.ttf", int(dp(self.text[1])))

	def blit(self):
		self.mouse = pg.mouse.get_pos()
		if not self.color[0] == "a":
			pg.draw.rect(self.con, self.color, (w(self.pos[0]), h(self.pos[1]), wx(self.size[0]), hy(self.size[1])), int(0), wx(self.round), hy(self.round), wx(self.round), hy(self.round))
		
		if self.focused:
			self.label = self.font.render(self.text[0], 1, self.text_color[1])
		else:
			self.label = self.font.render(self.text[0], 1, self.text_color[0])

		self.con.blit(self.label, (w(self.pos[0]+self.size[0]/4  - len(self.text[0]) * (self.text[1])/4), h(self.pos[1]+self.size[1]/12)))
		if self.selected:
			pg.draw.rect(self.con, self.select_color, (w(self.pos[0]), h(self.pos[1]), wx(self.size[0]), hy(self.size[1])), dp(3), wx(self.round), hy(self.round), wx(self.round), hy(self.round))

	def get_pressed(self, event):
		if self.rect.collidepoint(self.mouse):
			self.focused = True
			self.color = self.two_color
			if event.type == pg.MOUSEBUTTONDOWN:
				return True
				
		else:
			self.focused = False
			self.color = self.one_color
		return False
	def select(self):
		if self.selected:
			self.selected = False
		else:
			self.selected = True



class Label:
	def __init__(self, sc, pos, text, color, size, font = False):
		self.pos = pos
		self.sc = sc
		self.size = size
		self.text = text
		self.color = color
		if font:
			self.font = pg.font.Font(font, int(dp(self.size)))
		else:
			self.font = pg.font.Font("MonospaceOblique.ttf", int(dp(self.size)))
		

	def blit(self):
		self.label = self.font.render(self.text, 1, self.color)
		self.sc.blit(self.label, (w(self.pos[0]), h(self.pos[1])))