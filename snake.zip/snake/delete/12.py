#SKINS
RUS_SKIN = {
    'colors': [[255,255,255], [0,0,255], [255,0,0]],
    'lenght': 30
}
UA_SKIN = {
    'colors': [[0,0,255], [255,255,0]],
    'lenght': 30
}
current_skin = UA_SKIN
skin = []

for l in range(len(current_skin['colors'])):
    for t in range(int(current_skin['lenght']/len(current_skin['colors']))):
        skin.append(current_skin['colors'][l])

skin[sn % current_skin['lenght']]
